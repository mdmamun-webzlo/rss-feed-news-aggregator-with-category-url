<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_npa_save_source', array( __CLASS__, 'save_source' ) );
		add_action( 'admin_post_npa_delete_source', array( __CLASS__, 'delete_source' ) );
		add_action( 'admin_post_npa_fetch_source', array( __CLASS__, 'fetch_source' ) );
		add_action( 'admin_post_npa_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_npa_create_missing_posts', array( __CLASS__, 'create_missing_posts' ) );
		add_action( 'admin_post_npa_repair_cron', array( __CLASS__, 'repair_cron' ) );
		add_action( 'admin_post_npa_regenerate_full_content', array( __CLASS__, 'regenerate_full_content' ) );
		add_action( 'admin_post_npa_repair_bad_titles', array( __CLASS__, 'repair_bad_titles' ) );
	}

	public static function menu() {
		add_menu_page( 'News Aggregator', 'News Aggregator', 'manage_options', 'npa-dashboard', array( __CLASS__, 'dashboard' ), 'dashicons-rss', 26 );
		add_submenu_page( 'npa-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'npa-dashboard', array( __CLASS__, 'dashboard' ) );
		add_submenu_page( 'npa-dashboard', 'Sources', 'Sources', 'manage_options', 'npa-sources', array( __CLASS__, 'sources' ) );
		add_submenu_page( 'npa-dashboard', 'Add New Source', 'Add New Source', 'manage_options', 'npa-add-source', array( __CLASS__, 'source_form' ) );
		add_submenu_page( 'npa-dashboard', 'News Items', 'News Items', 'manage_options', 'npa-items', array( __CLASS__, 'items' ) );
		add_submenu_page( 'npa-dashboard', 'Settings', 'Settings', 'manage_options', 'npa-settings', array( __CLASS__, 'settings_page' ) );
		add_submenu_page( 'npa-dashboard', 'Logs', 'Logs', 'manage_options', 'npa-logs', array( __CLASS__, 'logs' ) );
		add_submenu_page( 'npa-dashboard', 'Help', 'Help', 'manage_options', 'npa-help', array( __CLASS__, 'help_page' ) );
	}

	public static function assets( $hook ) {
		if ( false !== strpos( $hook, 'npa-' ) ) wp_enqueue_style( 'npa-admin', NPA_URL . 'public/assets/css/admin.css', array(), NPA_VERSION );
	}

	private static function check() { if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permission denied.', 'news-portal-rss-aggregator' ) ); }

	public static function dashboard() {
		self::check(); global $wpdb;
		$sources = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . NPA_DB::table( 'sources' ) );
		$items = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . NPA_DB::table( 'items' ) );
		$active = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . NPA_DB::table( 'sources' ) . " WHERE status='active'" );
		$next = wp_next_scheduled( NPA_Cron::HOOK );
		$total_views = (int) $wpdb->get_var( "SELECT SUM(CAST(meta_value AS UNSIGNED)) FROM {$wpdb->postmeta} WHERE meta_key = '_npa_read_count'" );
		$total_posts = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s", '_npa_original_hash' ) );
		$top_posts = $wpdb->get_results( "SELECT p.ID, p.post_title, CAST(pm.meta_value AS UNSIGNED) AS views FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id INNER JOIN {$wpdb->postmeta} nh ON p.ID = nh.post_id AND nh.meta_key = '_npa_original_hash' WHERE pm.meta_key = '_npa_read_count' AND p.post_status IN ('publish','draft') ORDER BY views DESC, p.ID DESC LIMIT 10" );
		$category_rows = $wpdb->get_results( 'SELECT category_name, COUNT(*) total FROM ' . NPA_DB::table( 'items' ) . " WHERE category_name != '' GROUP BY category_name ORDER BY total DESC LIMIT 12" );
		?>
		<div class="wrap npa-admin"><h1>News Aggregator Dashboard</h1><?php self::notice(); ?>
		<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_repair_cron' ), 'npa_repair_cron' ) ); ?>">Repair Cron Runner</a></p>
		<div class="npa-stats"><div><strong><?php echo esc_html( $sources ); ?></strong><span>Sources</span></div><div><strong><?php echo esc_html( $active ); ?></strong><span>Active Sources</span></div><div><strong><?php echo esc_html( $items ); ?></strong><span>Saved News</span></div><div><strong><?php echo esc_html( $total_posts ); ?></strong><span>Created WP Posts</span></div><div><strong><?php echo esc_html( $total_views ); ?></strong><span>Total Views</span></div><div><strong><?php echo esc_html( $next ? date_i18n( 'Y-m-d H:i', $next ) : 'Not scheduled' ); ?></strong><span>Cron Runner</span></div></div>
		<div class="npa-dashboard-grid">
			<div class="npa-panel"><h2>Top Posts by Views</h2><table class="widefat striped"><thead><tr><th>Post</th><th>Views</th></tr></thead><tbody><?php foreach ( $top_posts as $post ) : ?><tr><td><a href="<?php echo esc_url( get_edit_post_link( absint( $post->ID ) ) ); ?>"><?php echo esc_html( $post->post_title ); ?></a></td><td><?php echo esc_html( absint( $post->views ) ); ?></td></tr><?php endforeach; if ( empty( $top_posts ) ) : ?><tr><td colspan="2">No view data yet.</td></tr><?php endif; ?></tbody></table></div>
			<div class="npa-panel"><h2>Posts by Category</h2><table class="widefat striped"><thead><tr><th>Category</th><th>Saved Items</th></tr></thead><tbody><?php foreach ( $category_rows as $row ) : ?><tr><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=npa-items&category=' . rawurlencode( $row->category_name ) ) ); ?>"><?php echo esc_html( $row->category_name ); ?></a></td><td><?php echo esc_html( absint( $row->total ) ); ?></td></tr><?php endforeach; if ( empty( $category_rows ) ) : ?><tr><td colspan="2">No categories found.</td></tr><?php endif; ?></tbody></table></div>
		</div>
		<p>Main shortcode: <code>[news_portal limit="60" layout="grid"]</code></p><p>Sidebar shortcode: <code>[news_portal_sidebar limit="10"]</code></p></div><?php
	}

	public static function repair_cron() {
		self::check();
		check_admin_referer( 'npa_repair_cron' );
		NPA_Cron::clear_runner();
		NPA_Cron::schedule_runner();
		wp_safe_redirect( admin_url( 'admin.php?page=npa-dashboard&npa_msg=cron_repaired' ) );
		exit;
	}

	public static function sources() {
		self::check(); global $wpdb;
		$sources = $wpdb->get_results( 'SELECT s.*, (SELECT COUNT(*) FROM ' . NPA_DB::table( 'items' ) . ' i WHERE i.source_id=s.id) total_items FROM ' . NPA_DB::table( 'sources' ) . ' s ORDER BY id DESC' );
		?>
		<div class="wrap npa-admin"><h1>Sources <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=npa-add-source' ) ); ?>">Add New</a></h1><?php self::notice(); ?>
		<table class="widefat striped"><thead><tr><th>Name</th><th>Category</th><th>Type</th><th>Frequency</th><th>Status</th><th>Last Run</th><th>Next Run</th><th>Total Saved</th><th>Last Status</th><th>Actions</th></tr></thead><tbody>
		<?php foreach ( $sources as $s ) : ?>
		<tr><td><strong><?php echo esc_html( $s->source_name ); ?></strong><br><a href="<?php echo esc_url( $s->source_url ); ?>" target="_blank" rel="noopener">Website</a></td><td><?php echo esc_html( $s->category_name ); ?></td><td><?php echo esc_html( $s->source_type ); ?></td><td><?php echo esc_html( $s->frequency ); ?></td><td><?php echo esc_html( $s->status ); ?></td><td><?php echo esc_html( $s->last_run ); ?></td><td><?php echo esc_html( $s->next_run ); ?></td><td><?php echo esc_html( $s->total_items ); ?></td><td><?php echo esc_html( $s->last_status ); ?></td><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=npa-add-source&id=' . absint( $s->id ) ) ); ?>">Edit</a> | <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_fetch_source&id=' . absint( $s->id ) ), 'npa_fetch_source' ) ); ?>">Fetch Now</a> | <a onclick="return confirm('Delete this source?');" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_delete_source&id=' . absint( $s->id ) ), 'npa_delete_source' ) ); ?>">Delete</a></td></tr>
		<?php endforeach; if ( empty( $sources ) ) : ?><tr><td colspan="10">No sources yet.</td></tr><?php endif; ?>
		</tbody></table></div><?php
	}

	public static function source_form() {
		self::check(); global $wpdb;
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$s = $id ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'sources' ) . ' WHERE id=%d', $id ) ) : null;
		$defaults = (object) array( 'id'=>0,'source_name'=>'','source_url'=>'','rss_url'=>'','category_name'=>'','source_type'=>'rss','frequency'=>'hourly','max_items'=>10,'status'=>'active' );
		$s = $s ? $s : $defaults;
		?>
		<div class="wrap npa-admin"><h1><?php echo $id ? 'Edit Source' : 'Add New Source'; ?></h1>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="npa-form">
		<input type="hidden" name="action" value="npa_save_source"><input type="hidden" name="id" value="<?php echo esc_attr( $s->id ); ?>"><?php wp_nonce_field( 'npa_save_source' ); ?>
		<label>Source Name<input required name="source_name" value="<?php echo esc_attr( $s->source_name ); ?>"></label>
		<label>Source Website URL<input type="url" name="source_url" value="<?php echo esc_url( $s->source_url ); ?>"></label>
		<label>RSS Feed URL<input type="url" name="rss_url" value="<?php echo esc_url( $s->rss_url ); ?>"></label>
		<label>Category Name<input name="category_name" value="<?php echo esc_attr( $s->category_name ); ?>"></label>
		<label>Source Type<select name="source_type"><option value="rss" <?php selected( $s->source_type, 'rss' ); ?>>RSS Feed</option><option value="category" <?php selected( $s->source_type, 'category' ); ?>>Category URL fallback</option></select></label>
		<label>Update Frequency<select name="frequency"><option value="hourly" <?php selected( $s->frequency, 'hourly' ); ?>>Hourly</option><option value="twicedaily" <?php selected( $s->frequency, 'twicedaily' ); ?>>Twice Daily</option><option value="daily" <?php selected( $s->frequency, 'daily' ); ?>>Daily</option></select></label>
		<label>Max Items Per Update<input type="number" min="1" max="100" name="max_items" value="<?php echo esc_attr( $s->max_items ); ?>"></label>
		<label>Status<select name="status"><option value="active" <?php selected( $s->status, 'active' ); ?>>Active</option><option value="paused" <?php selected( $s->status, 'paused' ); ?>>Paused</option></select></label>
		<?php submit_button( 'Save Source' ); ?></form></div><?php
	}

	public static function save_source() {
		self::check(); check_admin_referer( 'npa_save_source' ); global $wpdb;
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$data = array(
			'source_name' => sanitize_text_field( wp_unslash( $_POST['source_name'] ?? '' ) ),
			'source_url' => esc_url_raw( wp_unslash( $_POST['source_url'] ?? '' ) ),
			'rss_url' => esc_url_raw( wp_unslash( $_POST['rss_url'] ?? '' ) ),
			'category_name' => sanitize_text_field( wp_unslash( $_POST['category_name'] ?? '' ) ),
			'source_type' => in_array( $_POST['source_type'] ?? 'rss', array( 'rss','category' ), true ) ? sanitize_key( $_POST['source_type'] ) : 'rss',
			'frequency' => in_array( $_POST['frequency'] ?? 'hourly', array( 'hourly','twicedaily','daily' ), true ) ? sanitize_key( $_POST['frequency'] ) : 'hourly',
			'max_items' => max( 1, absint( $_POST['max_items'] ?? 10 ) ),
			'status' => in_array( $_POST['status'] ?? 'active', array( 'active','paused' ), true ) ? sanitize_key( $_POST['status'] ) : 'active',
			'updated_at' => current_time( 'mysql' ),
		);
		if ( $id ) { $wpdb->update( NPA_DB::table( 'sources' ), $data, array( 'id' => $id ) ); }
		else { $data['created_at'] = current_time( 'mysql' ); $data['next_run'] = current_time( 'mysql' ); $wpdb->insert( NPA_DB::table( 'sources' ), $data ); }
		wp_safe_redirect( admin_url( 'admin.php?page=npa-sources&npa_msg=saved' ) ); exit;
	}

	public static function delete_source() { self::check(); check_admin_referer( 'npa_delete_source' ); global $wpdb; $id = absint( $_GET['id'] ?? 0 ); $wpdb->delete( NPA_DB::table( 'sources' ), array( 'id'=>$id ), array( '%d' ) ); wp_safe_redirect( admin_url( 'admin.php?page=npa-sources&npa_msg=deleted' ) ); exit; }
	public static function fetch_source() { self::check(); check_admin_referer( 'npa_fetch_source' ); $id = absint( $_GET['id'] ?? 0 ); NPA_Fetcher::fetch_source( $id ); global $wpdb; $f = $wpdb->get_var( $wpdb->prepare( 'SELECT frequency FROM ' . NPA_DB::table( 'sources' ) . ' WHERE id=%d', $id ) ); NPA_Cron::set_next_run( $id, $f ? $f : 'daily' ); wp_safe_redirect( admin_url( 'admin.php?page=npa-sources&npa_msg=fetched' ) ); exit; }

	public static function items() {
		self::check(); global $wpdb;
		$source_filter = sanitize_text_field( wp_unslash( $_GET['source'] ?? '' ) );
		$category_filter = sanitize_text_field( wp_unslash( $_GET['category'] ?? '' ) );
		$where = array( '1=1' ); $params = array();
		if ( $source_filter ) { $where[] = 'source_name = %s'; $params[] = $source_filter; }
		if ( $category_filter ) { $where[] = 'category_name = %s'; $params[] = $category_filter; }
		$sql = 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY published_at DESC, id DESC LIMIT 300';
		$items = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
		$sources = $wpdb->get_col( 'SELECT DISTINCT source_name FROM ' . NPA_DB::table( 'items' ) . " WHERE source_name != '' ORDER BY source_name ASC" );
		$categories = $wpdb->get_col( 'SELECT DISTINCT category_name FROM ' . NPA_DB::table( 'items' ) . " WHERE category_name != '' ORDER BY category_name ASC" ); ?>
		<div class="wrap npa-admin"><h1>News Items</h1><?php self::notice(); ?>
		<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_create_missing_posts' ), 'npa_create_missing_posts' ) ); ?>">Create Missing WP Posts</a> <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_repair_bad_titles' ), 'npa_repair_bad_titles' ) ); ?>">Repair Bad Titles</a></p>
		<form method="get" class="npa-filter-form"><input type="hidden" name="page" value="npa-items"><label>Source <select name="source"><option value="">All Sources</option><?php foreach ( $sources as $source ) : ?><option value="<?php echo esc_attr( $source ); ?>" <?php selected( $source_filter, $source ); ?>><?php echo esc_html( $source ); ?></option><?php endforeach; ?></select></label><label>Category <select name="category"><option value="">All Categories</option><?php foreach ( $categories as $category ) : ?><option value="<?php echo esc_attr( $category ); ?>" <?php selected( $category_filter, $category ); ?>><?php echo esc_html( $category ); ?></option><?php endforeach; ?></select></label><button class="button">Filter</button><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=npa-items' ) ); ?>">Reset</a></form>
		<table class="widefat striped"><thead><tr><th>Title</th><th>Source</th><th>Category</th><th>Date</th><th>Views</th><th>WP Post</th><th>Original Link</th></tr></thead><tbody>
		<?php foreach ( $items as $i ) : $views = ! empty( $i->post_id ) ? absint( get_post_meta( absint( $i->post_id ), '_npa_read_count', true ) ) : 0; ?>
		<tr><td><?php echo esc_html( $i->title ); ?></td><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=npa-items&source=' . rawurlencode( $i->source_name ) ) ); ?>"><?php echo esc_html( $i->source_name ); ?></a></td><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=npa-items&category=' . rawurlencode( $i->category_name ) ) ); ?>"><?php echo esc_html( $i->category_name ); ?></a></td><td><?php echo esc_html( $i->published_at ); ?></td><td><?php echo esc_html( $views ); ?></td><td><?php if ( ! empty( $i->post_id ) ) : ?><a href="<?php echo esc_url( get_edit_post_link( absint( $i->post_id ) ) ); ?>">Edit Post</a> | <a href="<?php echo esc_url( get_permalink( absint( $i->post_id ) ) ); ?>" target="_blank" rel="noopener">View</a><?php else : ?>—<?php endif; ?></td><td><a href="<?php echo esc_url( $i->link ); ?>" target="_blank" rel="noopener">Open</a></td></tr>
		<?php endforeach; if ( empty( $items ) ) : ?><tr><td colspan="7">No news items found.</td></tr><?php endif; ?></tbody></table></div><?php
	}

	public static function create_missing_posts() { self::check(); check_admin_referer( 'npa_create_missing_posts' ); $created = NPA_Fetcher::create_missing_posts( 200 ); wp_safe_redirect( admin_url( 'admin.php?page=npa-items&npa_msg=created-' . absint( $created ) . '-posts' ) ); exit; }

	public static function repair_bad_titles() { self::check(); check_admin_referer( 'npa_repair_bad_titles' ); $updated = NPA_Fetcher::repair_bad_titles( 300 ); wp_safe_redirect( admin_url( 'admin.php?page=npa-items&npa_msg=repaired-' . absint( $updated ) . '-titles' ) ); exit; }

	public static function settings_page() { self::check(); $s = NPA_DB::settings(); ?><div class="wrap npa-admin"><h1>Settings</h1><?php self::notice(); ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="npa-form"><input type="hidden" name="action" value="npa_save_settings"><?php wp_nonce_field( 'npa_save_settings' ); ?>
		<h2>Post Creation</h2>
		<label><input type="checkbox" name="create_wp_posts" value="1" <?php checked( $s['create_wp_posts'], 1 ); ?>> Create real WordPress posts from fetched news</label>
		<label><input type="checkbox" name="auto_publish" value="1" <?php checked( $s['auto_publish'], 1 ); ?>> Auto publish created posts</label>
		<label>Post Status<select name="post_status"><option value="publish" <?php selected( $s['post_status'], 'publish' ); ?>>Publish</option><option value="draft" <?php selected( $s['post_status'], 'draft' ); ?>>Draft</option></select></label>
		<label><input type="checkbox" name="download_featured_image" value="1" <?php checked( $s['download_featured_image'], 1 ); ?>> Download and set featured image automatically</label>
		<label>Post Content Mode<select name="content_mode"><option value="summary" <?php selected( $s['content_mode'], 'summary' ); ?>>Safe summary only</option><option value="rss_full" <?php selected( $s['content_mode'], 'rss_full' ); ?>>Use full RSS content if feed provides it</option><option value="extract_full" <?php selected( $s['content_mode'], 'extract_full' ); ?>>Extract full article from original URL</option></select><small>Private-site mode. Extracts article body from the original URL when possible.</small></label>
		<label>Custom Article Extractor Selectors<textarea name="extractor_selectors" rows="5" placeholder="article&#10;.article__content&#10;.entry-content"><?php echo esc_textarea( $s['extractor_selectors'] ); ?></textarea><small>Optional. One CSS selector per line. Put domain-specific selectors first for better full article extraction.</small></label>
		<p><a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=npa_regenerate_full_content' ), 'npa_regenerate_full_content' ) ); ?>">Regenerate Full Content for Existing Posts</a></p>
		<h2>Aggregator Display</h2>
		<label>Default Items Per Source<input type="number" name="default_items_per_source" value="<?php echo esc_attr( $s['default_items_per_source'] ); ?>"></label>
		<label>Cache Duration Minutes<input type="number" name="cache_duration" value="<?php echo esc_attr( $s['cache_duration'] ); ?>"></label>
		<label>Default Fallback Image URL<input type="url" name="default_fallback_image" value="<?php echo esc_url( $s['default_fallback_image'] ); ?>"></label>
		<label>Auto Delete News Older Than X Days<input type="number" name="auto_delete_days" value="<?php echo esc_attr( $s['auto_delete_days'] ); ?>"><small>0 = disabled</small></label>
		<label>Max Stored Items Per Source<input type="number" name="max_stored_per_source" value="<?php echo esc_attr( $s['max_stored_per_source'] ); ?>"><small>0 = unlimited</small></label>
		<label><input type="checkbox" name="open_new_tab" value="1" <?php checked( $s['open_new_tab'], 1 ); ?>> Open links in new tab</label>
		<label><input type="checkbox" name="nofollow_links" value="1" <?php checked( $s['nofollow_links'], 1 ); ?>> Add nofollow to external links</label>
		<label><input type="checkbox" name="show_source" value="1" <?php checked( $s['show_source'], 1 ); ?>> Show source name</label>
		<label><input type="checkbox" name="show_date" value="1" <?php checked( $s['show_date'], 1 ); ?>> Show date</label>
		<label><input type="checkbox" name="show_excerpt" value="1" <?php checked( $s['show_excerpt'], 1 ); ?>> Show excerpt</label><?php submit_button( 'Save Settings' ); ?></form></div><?php }

	public static function save_settings() {
		self::check(); check_admin_referer( 'npa_save_settings' );
		$post_status = in_array( $_POST['post_status'] ?? 'publish', array( 'publish', 'draft' ), true ) ? sanitize_key( $_POST['post_status'] ) : 'publish';
		$content_mode = in_array( $_POST['content_mode'] ?? 'summary', array( 'summary', 'rss_full', 'extract_full' ), true ) ? sanitize_key( $_POST['content_mode'] ) : 'summary';
		$s = array(
			'default_items_per_source'=>absint($_POST['default_items_per_source']??10),
			'cache_duration'=>absint($_POST['cache_duration']??30),
			'default_fallback_image'=>esc_url_raw(wp_unslash($_POST['default_fallback_image']??'')),
			'auto_delete_days'=>absint($_POST['auto_delete_days']??0),
			'max_stored_per_source'=>absint($_POST['max_stored_per_source']??0),
			'open_new_tab'=>isset($_POST['open_new_tab'])?1:0,
			'nofollow_links'=>isset($_POST['nofollow_links'])?1:0,
			'show_source'=>isset($_POST['show_source'])?1:0,
			'show_date'=>isset($_POST['show_date'])?1:0,
			'show_excerpt'=>isset($_POST['show_excerpt'])?1:0,
			'create_wp_posts'=>isset($_POST['create_wp_posts'])?1:0,
			'auto_publish'=>isset($_POST['auto_publish'])?1:0,
			'post_status'=>$post_status,
			'download_featured_image'=>isset($_POST['download_featured_image'])?1:0,
			'content_mode'=>$content_mode,
			'extractor_selectors'=>sanitize_textarea_field( wp_unslash( $_POST['extractor_selectors'] ?? '' ) ),
		);
		update_option( 'npa_settings', $s );
		wp_safe_redirect( admin_url( 'admin.php?page=npa-settings&npa_msg=saved' ) ); exit;
	}


	public static function regenerate_full_content() {
		self::check();
		check_admin_referer( 'npa_regenerate_full_content' );
		$updated = NPA_Fetcher::regenerate_full_content_posts( 100 );
		wp_safe_redirect( admin_url( 'admin.php?page=npa-settings&npa_msg=regenerated-' . absint( $updated ) . '-posts' ) );
		exit;
	}

	public static function logs() { self::check(); global $wpdb; $logs = $wpdb->get_results( 'SELECT l.*, s.source_name FROM ' . NPA_DB::table( 'logs' ) . ' l LEFT JOIN ' . NPA_DB::table( 'sources' ) . ' s ON s.id=l.source_id ORDER BY l.id DESC LIMIT 200' ); ?><div class="wrap npa-admin"><h1>Logs</h1><table class="widefat striped"><thead><tr><th>Date</th><th>Source</th><th>Level</th><th>Message</th></tr></thead><tbody><?php foreach ( $logs as $l ) : ?><tr><td><?php echo esc_html( $l->created_at ); ?></td><td><?php echo esc_html( $l->source_name ); ?></td><td><?php echo esc_html( $l->level ); ?></td><td><?php echo esc_html( $l->message ); ?></td></tr><?php endforeach; ?></tbody></table></div><?php }


	public static function help_page() {
		self::check(); ?>
		<div class="wrap npa-admin">
			<h1>News Aggregator Help</h1>
			<div class="npa-help-box">
				<h2>Best way to build the grid layout</h2>
				<p><strong>Recommended:</strong> use the Elementor widget named <strong>News Portal Grid</strong>. It lets you control columns without shortcode work.</p>
				<ol>
					<li>Edit any page with Elementor.</li>
					<li>Search widget: <strong>News Portal Grid</strong>.</li>
					<li>Set <strong>Number of Posts</strong>: 1 to 60.</li>
					<li>Set <strong>Columns</strong>: 1, 2, 3, or 4.</li>
					<li>Optional: filter by <strong>Source</strong> or <strong>Category</strong> using dropdown controls.</li>
					<li>Open the <strong>Style</strong> tab to control grid gap, card background, border, radius, image height, typography, colors, and button design.</li>
					<li>Optional: order by <strong>Newest</strong> or <strong>Most Read</strong>.</li>
				</ol>
			</div>

			<div class="npa-help-box">
				<h2>Shortcodes</h2>
				<p>Shortcodes are still useful for normal WordPress pages, Gutenberg, sidebars, footer widgets, and quick testing.</p>
				<table class="widefat striped">
					<thead><tr><th>Use Case</th><th>Shortcode</th></tr></thead>
					<tbody>
						<tr><td>Default news grid</td><td><code>[news_portal]</code></td></tr>
						<tr><td>Show 40 posts</td><td><code>[news_portal limit="40" columns="4"]</code></td></tr>
						<tr><td>Show 60 posts</td><td><code>[news_portal limit="60" columns="4"]</code></td></tr>
						<tr><td>Filter by source</td><td><code>[news_portal source="BBC" limit="12" columns="3"]</code></td></tr>
						<tr><td>Filter by category</td><td><code>[news_portal category="World" limit="12" columns="3"]</code></td></tr>
						<tr><td>Show many posts by category</td><td><code>[news_portal category="Politics" limit="60" columns="4"]</code></td></tr>
						<tr><td>Sidebar list: image left, title right</td><td><code>[news_portal_sidebar limit="10"]</code></td></tr>
						<tr><td>Sidebar list by source</td><td><code>[news_portal_sidebar source="CNN Politics" limit="8"]</code></td></tr>
					</tbody>
				</table>
			</div>

			<div class="npa-help-box">
				<h2>Important content note</h2>
				<p>This plugin creates WordPress posts from fetched news. For major publishers, RSS normally provides title, excerpt, image, and original link, not the full article body. Use <strong>Settings → Post Content Mode → Use full RSS content if feed provides it</strong> for sources that legally provide full RSS content.</p>
			</div>
		</div>
		<?php
	}

	private static function notice() { if ( ! empty( $_GET['npa_msg'] ) ) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['npa_msg'] ) ) ) . '</p></div>'; }
}
