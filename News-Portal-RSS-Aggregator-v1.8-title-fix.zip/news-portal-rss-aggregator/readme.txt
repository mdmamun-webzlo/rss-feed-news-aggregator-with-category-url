=== News Portal RSS Aggregator ===
Contributors: webzlo
Tags: rss, news, aggregator, portal
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 1.6.0
License: GPLv2 or later

Stores RSS/category URL news items in custom database tables and displays them via shortcode.

Shortcodes:
[news_portal]
[news_portal source="BBC"]
[news_portal category="World"]
[news_portal limit="12"]
[news_portal layout="grid"]

= 1.5.0 =
* Added dashboard Total Views and Created WP Posts counters.
* Added Top Posts by Views table in the backend.
* Added Posts by Category report in the backend.
* Added News Items source/category filters.
* Improved Elementor widget category/source dropdown filters.
* Added Elementor Style tab controls for card, grid, image, text, meta, and button design.
