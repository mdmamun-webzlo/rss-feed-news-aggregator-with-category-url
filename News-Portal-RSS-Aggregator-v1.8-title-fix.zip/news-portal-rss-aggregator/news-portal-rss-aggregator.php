<?php
/**
 * Plugin Name: News Portal RSS Aggregator
 * Description: Stores and displays RSS/category news items as a lightweight news portal aggregator.
 * Version: 1.8.0
 * Author: Md Mamun Miah | Webzlo
 * Author URI: https://webzlo.com/
 * Text Domain: news-portal-rss-aggregator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NPA_VERSION', '1.8.0' );
define( 'NPA_FILE', __FILE__ );
define( 'NPA_DIR', plugin_dir_path( __FILE__ ) );
define( 'NPA_URL', plugin_dir_url( __FILE__ ) );

require_once NPA_DIR . 'includes/class-npa-db.php';
require_once NPA_DIR . 'includes/class-npa-fetcher.php';
require_once NPA_DIR . 'includes/class-npa-cron.php';
require_once NPA_DIR . 'includes/class-npa-shortcodes.php';
require_once NPA_DIR . 'includes/class-npa-elementor.php';
require_once NPA_DIR . 'admin/class-npa-admin.php';

final class News_Portal_RSS_Aggregator {
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( get_option( 'npa_db_version' ) !== NPA_VERSION ) { NPA_DB::create_tables(); NPA_DB::maybe_default_options(); }
		NPA_Cron::init();
		NPA_Shortcodes::init();
		NPA_Elementor::init();
		if ( is_admin() ) {
			NPA_Admin::init();
		}
	}

	public static function activate() {
		NPA_DB::create_tables();
		NPA_DB::maybe_default_options();
		NPA_Cron::init();
		NPA_Cron::schedule_runner();
	}

	public static function deactivate() {
		NPA_Cron::clear_runner();
	}
}

register_activation_hook( __FILE__, array( 'News_Portal_RSS_Aggregator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'News_Portal_RSS_Aggregator', 'deactivate' ) );

News_Portal_RSS_Aggregator::instance();
