<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_Fetcher {
	public static function fetch_source( $source_id ) {
		global $wpdb;
		$source = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'sources' ) . ' WHERE id = %d', absint( $source_id ) ) );
		if ( ! $source ) { return array( 'saved' => 0, 'skipped' => 0, 'error' => 'Source not found.' ); }

		$items = ( 'category' === $source->source_type ) ? self::fetch_category_url( $source ) : self::fetch_rss( $source );
		if ( is_wp_error( $items ) ) {
			self::update_source_status( $source->id, 'failed', $items->get_error_message() );
			NPA_DB::log( $source->id, 'error', $items->get_error_message() );
			return array( 'saved' => 0, 'skipped' => 0, 'error' => $items->get_error_message() );
		}

		$saved = 0; $skipped = 0;
		foreach ( $items as $item ) {
			$result = self::save_item( $source, $item );
			if ( $result ) { $saved++; } else { $skipped++; }
		}

		self::cleanup( $source->id );
		$msg = sprintf( 'Fetch complete. Saved: %d, skipped duplicates/errors: %d.', $saved, $skipped );
		self::update_source_status( $source->id, 'success', $msg );
		NPA_DB::log( $source->id, 'info', $msg );
		return array( 'saved' => $saved, 'skipped' => $skipped, 'error' => '' );
	}

	private static function fetch_rss( $source ) {
		include_once ABSPATH . WPINC . '/feed.php';
		$url = esc_url_raw( $source->rss_url ? $source->rss_url : $source->source_url );
		if ( ! self::is_safe_remote_url( $url ) ) { return new WP_Error( 'npa_unsafe_url', 'Unsafe or unsupported RSS URL.' ); }
		$feed = fetch_feed( $url );
		if ( is_wp_error( $feed ) ) { return $feed; }
		$max = max( 1, absint( $source->max_items ) );
		$count = $feed->get_item_quantity( $max );
		$feed_items = $feed->get_items( 0, $count );
		$data = array();
		foreach ( $feed_items as $entry ) {
			$link = esc_url_raw( $entry->get_permalink() );
			if ( ! $link || ! self::is_safe_remote_url( $link ) ) { continue; }
			$title = self::clean_title( (string) $entry->get_title() );
			$description_raw = (string) $entry->get_description();
			$content_raw = (string) $entry->get_content();
			$data[] = array(
				'title'             => $title,
				'link'              => $link,
				'description'       => self::clean_excerpt( $description_raw ),
				'content_encoded'   => self::clean_content( $content_raw ),
				'published_at'      => $entry->get_date( 'Y-m-d H:i:s' ),
				'guid'              => sanitize_text_field( (string) $entry->get_id() ),
				'image_url'         => esc_url_raw( self::extract_feed_image( $entry ) ),
				'description_html'  => $description_raw,
			);
		}
		return $data;
	}

	private static function extract_feed_image( $entry ) {
		$media = $entry->get_item_tags( 'http://search.yahoo.com/mrss/', 'content' );
		if ( ! empty( $media[0]['attribs']['']['url'] ) ) { return $media[0]['attribs']['']['url']; }
		$thumb = $entry->get_item_tags( 'http://search.yahoo.com/mrss/', 'thumbnail' );
		if ( ! empty( $thumb[0]['attribs']['']['url'] ) ) { return $thumb[0]['attribs']['']['url']; }
		$enclosure = $entry->get_enclosure();
		if ( $enclosure && $enclosure->get_link() && false !== strpos( (string) $enclosure->get_type(), 'image/' ) ) { return $enclosure->get_link(); }
		foreach ( array( $entry->get_description(), $entry->get_content() ) as $html ) {
			if ( preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/i', (string) $html, $m ) ) { return $m[1]; }
		}
		return '';
	}

	private static function fetch_category_url( $source ) {
		$url = esc_url_raw( $source->source_url );
		if ( ! self::is_safe_remote_url( $url ) ) { return new WP_Error( 'npa_unsafe_url', 'Unsafe or unsupported category URL.' ); }
		$response = wp_safe_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3, 'user-agent' => 'WordPress News Portal RSS Aggregator/' . NPA_VERSION ) );
		if ( is_wp_error( $response ) ) { return $response; }
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== absint( $code ) ) { return new WP_Error( 'npa_bad_response', 'Category URL returned HTTP ' . absint( $code ) ); }
		$html = wp_remote_retrieve_body( $response );
		if ( empty( $html ) ) { return new WP_Error( 'npa_empty_body', 'Category URL returned empty body.' ); }

		$doc = self::html_doc( $html );
		$xpath = new DOMXPath( $doc );
		$nodes = $xpath->query( '//a[@href]' );
		$items = array(); $seen = array(); $max = max( 1, absint( $source->max_items ) );
		foreach ( $nodes as $node ) {
			$link = esc_url_raw( self::absolute_url( $node->getAttribute( 'href' ), $url ) );
			if ( ! $link || isset( $seen[ md5( $link ) ] ) || ! self::is_safe_remote_url( $link ) || ! self::looks_like_article( $link, $url ) ) { continue; }
			$title = self::extract_anchor_title( $node );
			if ( self::is_bad_title( $title ) || strlen( $title ) < 25 ) { continue; }
			$img = '';
			$imgnode = $xpath->query( './/img', $node )->item( 0 );
			if ( $imgnode ) { $img = self::absolute_url( $imgnode->getAttribute( 'src' ), $url ); }
			$items[] = array(
				'title' => self::clean_title( $title ),
				'link' => $link,
				'description' => '',
				'content_encoded' => '',
				'published_at' => current_time( 'mysql' ),
				'guid' => $link,
				'image_url' => esc_url_raw( $img ),
				'description_html' => '',
			);
			$seen[ md5( $link ) ] = true;
			if ( count( $items ) >= $max ) { break; }
		}
		return $items;
	}

	private static function save_item( $source, $item ) {
		global $wpdb;
		$link = esc_url_raw( $item['link'] );
		if ( ! self::is_safe_remote_url( $link ) ) { return false; }
		$hash = self::url_hash( $link );
		$guid = ! empty( $item['guid'] ) ? sanitize_text_field( $item['guid'] ) : $link;
		$existing_item = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE url_hash = %s OR link = %s OR guid = %s LIMIT 1', $hash, $link, $guid ) );
		if ( $existing_item ) {
			self::maybe_create_missing_post_for_item( $existing_item );
			return false;
		}
		if ( self::post_exists_by_hash( $hash ) ) { return false; }

		$article = self::fetch_article_meta( $link );
		$item['_article_full_content'] = ! empty( $article['full_content'] ) ? $article['full_content'] : '';
		$title = ! empty( $item['title'] ) && ! self::is_bad_title( $item['title'] ) ? $item['title'] : ( $article['og_title'] ?: ( $article['title_tag'] ?: $article['h1'] ) );
		$title = self::clean_title( $title );
		if ( empty( $title ) || self::is_bad_title( $title ) ) { return false; }

		$excerpt = ! empty( $item['description'] ) ? $item['description'] : ( ! empty( $item['content_encoded'] ) ? $item['content_encoded'] : ( $article['meta_description'] ?: $article['first_paragraph'] ) );
		$excerpt = self::clean_excerpt( $excerpt );
		$image = self::choose_image( $item, $article );
		$post_id = 0;
		$settings = NPA_DB::settings();

		if ( ! empty( $settings['create_wp_posts'] ) ) {
			$post_id = self::create_wp_post( $source, $title, $excerpt, $link, $hash, $image, $item );
			if ( is_wp_error( $post_id ) || ! $post_id ) {
				NPA_DB::log( $source->id, 'error', 'Post create failed: ' . ( is_wp_error( $post_id ) ? $post_id->get_error_message() : $title ) );
				return false;
			}
		}

		return (bool) $wpdb->insert( NPA_DB::table( 'items' ), array(
			'post_id'       => absint( $post_id ),
			'source_id'     => absint( $source->id ),
			'source_name'   => sanitize_text_field( $source->source_name ),
			'category_name' => sanitize_text_field( $source->category_name ),
			'title'         => $title,
			'link'          => $link,
			'description'   => $excerpt,
			'image_url'     => esc_url_raw( $image ),
			'guid'          => $guid,
			'url_hash'      => $hash,
			'published_at'  => ! empty( $item['published_at'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $item['published_at'] ) ) : current_time( 'mysql' ),
			'created_at'    => current_time( 'mysql' ),
		), array( '%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) );
	}


	public static function create_missing_posts( $limit = 100 ) {
		global $wpdb;
		$limit = max( 1, min( 500, absint( $limit ) ) );
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE post_id = 0 ORDER BY id DESC LIMIT %d', $limit ) );
		$created = 0;
		foreach ( $items as $item ) {
			if ( self::maybe_create_missing_post_for_item( $item ) ) {
				$created++;
			}
		}
		return $created;
	}


	public static function repair_bad_titles( $limit = 200 ) {
		global $wpdb;
		$limit = max( 1, min( 500, absint( $limit ) ) );
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT id, post_id, title, link FROM ' . NPA_DB::table( 'items' ) . ' ORDER BY id DESC LIMIT %d', $limit ) );
		$updated = 0;
		foreach ( $items as $item ) {
			if ( ! self::is_bad_title( $item->title ) ) { continue; }
			$article = self::fetch_article_meta( $item->link );
			$new_title = self::clean_title( $article['og_title'] ?: ( $article['title_tag'] ?: $article['h1'] ) );
			if ( empty( $new_title ) || self::is_bad_title( $new_title ) ) { continue; }
			$wpdb->update( NPA_DB::table( 'items' ), array( 'title' => $new_title ), array( 'id' => absint( $item->id ) ), array( '%s' ), array( '%d' ) );
			if ( ! empty( $item->post_id ) && get_post( absint( $item->post_id ) ) ) {
				wp_update_post( array( 'ID' => absint( $item->post_id ), 'post_title' => $new_title ) );
			}
			$updated++;
		}
		return $updated;
	}

	private static function maybe_create_missing_post_for_item( $existing_item ) {
		global $wpdb;
		if ( empty( $existing_item ) || ! empty( $existing_item->post_id ) ) { return false; }
		$settings = NPA_DB::settings();
		if ( empty( $settings['create_wp_posts'] ) ) { return false; }
		if ( self::post_exists_by_hash( $existing_item->url_hash ) ) { return false; }
		$source = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'sources' ) . ' WHERE id = %d', absint( $existing_item->source_id ) ) );
		if ( ! $source ) {
			$source = (object) array(
				'id'            => absint( $existing_item->source_id ),
				'source_name'   => sanitize_text_field( $existing_item->source_name ),
				'source_url'    => esc_url_raw( $existing_item->link ),
				'category_name' => sanitize_text_field( $existing_item->category_name ),
			);
		}
		$post_id = self::create_wp_post(
			$source,
			sanitize_text_field( $existing_item->title ),
			self::clean_excerpt( $existing_item->description ),
			esc_url_raw( $existing_item->link ),
			sanitize_text_field( $existing_item->url_hash ),
			esc_url_raw( $existing_item->image_url ),
			array( 'guid' => sanitize_text_field( $existing_item->guid ) )
		);
		if ( is_wp_error( $post_id ) || ! $post_id ) { return false; }
		$wpdb->update( NPA_DB::table( 'items' ), array( 'post_id' => absint( $post_id ) ), array( 'id' => absint( $existing_item->id ) ), array( '%d' ), array( '%d' ) );
		return true;
	}

	private static function create_wp_post( $source, $title, $excerpt, $link, $hash, $image, $item ) {
		$settings = NPA_DB::settings();
		$status = in_array( $settings['post_status'], array( 'publish', 'draft' ), true ) ? $settings['post_status'] : 'publish';
		if ( empty( $settings['auto_publish'] ) ) { $status = 'draft'; }
		$cat_id = self::get_or_create_category( $source->category_name );
		$content = self::build_post_content( $source, $excerpt, $link, $item );
		$postarr = array(
			'post_type'    => 'post',
			'post_status'  => $status,
			'post_title'   => $title,
			'post_excerpt' => $excerpt,
			'post_content' => $content,
			'post_category'=> $cat_id ? array( $cat_id ) : array(),
			'meta_input'   => array(
				'_npa_source_name'   => sanitize_text_field( $source->source_name ),
				'_npa_original_url'  => esc_url_raw( $link ),
				'_npa_original_hash' => sanitize_text_field( $hash ),
				'_npa_guid'          => sanitize_text_field( $item['guid'] ?? '' ),
				'_npa_read_count'    => 0,
			),
		);
		$post_id = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $post_id ) || ! $post_id ) { return $post_id; }
		if ( ! empty( $settings['download_featured_image'] ) && $image && self::is_safe_remote_url( $image ) ) {
			self::set_featured_image( $post_id, $image, $title );
		}
		return $post_id;
	}

	private static function build_post_content( $source, $excerpt, $link, $item = array() ) {
		$settings = NPA_DB::settings();
		$source_name = sanitize_text_field( $source->source_name );
		$mode = isset( $settings['content_mode'] ) ? sanitize_key( $settings['content_mode'] ) : 'summary';
		$content = '';

		if ( 'extract_full' === $mode && ! empty( $item['_article_full_content'] ) ) {
			$content = wp_kses_post( $item['_article_full_content'] );
		} elseif ( 'rss_full' === $mode && ! empty( $item['content_encoded'] ) ) {
			$content = wp_kses_post( wpautop( $item['content_encoded'] ) );
		}

		if ( empty( trim( wp_strip_all_tags( $content ) ) ) ) {
			$content = wp_kses_post( wpautop( $excerpt ) );
		}

		if ( 'extract_full' === $mode ) {
			return $content;
		}

		$url = esc_url( $link );
		$note = '<p class="npa-source-note">Source: <strong>' . esc_html( $source_name ) . '</strong>. This post is stored from an RSS/feed or allowed source summary.</p>';
		$button = '<p><a class="npa-original-button" href="' . $url . '" target="_blank" rel="nofollow noopener noreferrer">Read Original Source</a></p>';
		return $content . $note . $button;
	}

	private static function get_or_create_category( $name ) {
		$name = sanitize_text_field( $name );
		if ( empty( $name ) ) { return 0; }
		$term = term_exists( $name, 'category' );
		if ( $term && ! is_wp_error( $term ) ) { return absint( is_array( $term ) ? $term['term_id'] : $term ); }
		$created = wp_insert_term( $name, 'category' );
		return ( is_wp_error( $created ) || empty( $created['term_id'] ) ) ? 0 : absint( $created['term_id'] );
	}

	private static function set_featured_image( $post_id, $image_url, $title ) {
		if ( has_post_thumbnail( $post_id ) ) { return; }
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_sideload_image( esc_url_raw( $image_url ), $post_id, sanitize_text_field( $title ), 'id' );
		if ( ! is_wp_error( $attachment_id ) ) { set_post_thumbnail( $post_id, absint( $attachment_id ) ); }
	}

	private static function post_exists_by_hash( $hash ) {
		$q = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'any', 'fields' => 'ids', 'posts_per_page' => 1, 'meta_key' => '_npa_original_hash', 'meta_value' => sanitize_text_field( $hash ), 'no_found_rows' => true ) );
		return ! empty( $q->posts );
	}

	private static function extract_anchor_title( $node ) {
		foreach ( array( 'aria-label', 'title' ) as $attr ) {
			$value = $node->getAttribute( $attr );
			if ( ! empty( $value ) && ! self::is_bad_title( $value ) ) {
				return self::clean_title( $value );
			}
		}

		$xp = new DOMXPath( $node->ownerDocument );
		$candidates = $xp->query( './/*[self::h1 or self::h2 or self::h3 or self::h4 or self::span or self::p][string-length(normalize-space()) > 20]', $node );
		if ( $candidates && $candidates->length ) {
			foreach ( $candidates as $candidate ) {
				$text = self::clean_title( $candidate->textContent );
				if ( ! self::is_bad_title( $text ) && strlen( $text ) >= 25 ) {
					return $text;
				}
			}
		}

		$clone = $node->cloneNode( true );
		$doc = new DOMDocument();
		$imported = $doc->importNode( $clone, true );
		$doc->appendChild( $imported );
		$clone_xp = new DOMXPath( $doc );
		foreach ( $clone_xp->query( '//script|//style|//noscript|//picture|//source|//img|//svg|//figure|//figcaption|//*[contains(@class,"caption") or contains(@class,"byline") or contains(@class,"metadata") or contains(@class,"image") or contains(@class,"media") or contains(@class,"video")]' ) as $bad ) {
			if ( $bad->parentNode ) { $bad->parentNode->removeChild( $bad ); }
		}
		return self::clean_title( $doc->textContent );
	}

	private static function clean_title( $title ) {
		$title = html_entity_decode( wp_strip_all_tags( (string) $title ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$title = preg_replace( '/function\s+imageLoadError\s*\([^\)]*\)\s*\{.*?\}/is', ' ', $title );
		$title = preg_replace( '/\b(const|let|var)\s+[a-z0-9_]+\s*=.*?;/is', ' ', $title );
		$title = preg_replace( '/\b(Source|Video)\s*[:•]?\s*/i', ' ', $title );
		$title = preg_replace( '/\s+/', ' ', $title );
		$title = trim( $title, " \t\n\r\0\x0B-|–—»«•" );
		if ( strlen( $title ) > 180 ) {
			$title = wp_trim_words( $title, 22, '' );
		}
		return sanitize_text_field( $title );
	}

	private static function is_bad_title( $title ) {
		$title = trim( (string) $title );
		if ( empty( $title ) ) { return true; }
		$lower = strtolower( $title );
		$bad_fragments = array(
			'function imageloaderror', 'fallbackimage', 'previousElementSibling', 'dataset.imgcssvars',
			'getty images', '/ap/file', 'nurphoto', 'afp/getty', 'the boston globe', 'courtesy',
			'newsletter', 'sign up', 'subscribe', 'advertisement', 'privacy policy', 'terms of use',
		);
		foreach ( $bad_fragments as $bad ) {
			if ( false !== strpos( $lower, strtolower( $bad ) ) ) { return true; }
		}
		if ( preg_match( '/^(video\s*)?\d{1,2}:\d{2}$/i', $title ) ) { return true; }
		if ( preg_match( '/^(ap|reuters|afp|getty images|cnn)$/i', $title ) ) { return true; }
		return false;
	}

	private static function fetch_article_meta( $url ) {
		$empty = array( 'og_image'=>'', 'og_title'=>'', 'title_tag'=>'', 'h1'=>'', 'meta_description'=>'', 'first_paragraph'=>'', 'full_content'=>'' );
		if ( ! self::is_safe_remote_url( $url ) ) { return $empty; }
		$response = wp_safe_remote_get( $url, array( 'timeout' => 10, 'redirection' => 3, 'user-agent' => 'WordPress News Portal RSS Aggregator/' . NPA_VERSION ) );
		if ( is_wp_error( $response ) || 200 !== absint( wp_remote_retrieve_response_code( $response ) ) ) { return $empty; }
		$html = wp_remote_retrieve_body( $response );
		if ( empty( $html ) ) { return $empty; }
		$doc = self::html_doc( $html );
		$xp = new DOMXPath( $doc );
		return array(
			'og_image' => self::absolute_url( self::meta_content( $xp, 'property', 'og:image' ), $url ),
			'og_title' => self::clean_title( self::meta_content( $xp, 'property', 'og:title' ) ),
			'title_tag' => self::clean_title( $xp->query( '//title' )->item( 0 )->textContent ?? '' ),
			'h1' => self::clean_title( $xp->query( '//h1' )->item( 0 )->textContent ?? '' ),
			'meta_description' => self::meta_content( $xp, 'name', 'description' ),
			'first_paragraph' => trim( $xp->query( '//article//p | //p' )->item( 0 )->textContent ?? '' ),
			'full_content' => self::extract_article_content( $doc, $xp, $url ),
		);
	}

	public static function regenerate_full_content_posts( $limit = 100 ) {
		global $wpdb;
		$limit = max( 1, min( 300, absint( $limit ) ) );
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE post_id > 0 ORDER BY id DESC LIMIT %d', $limit ) );
		$updated = 0;
		foreach ( $items as $item ) {
			if ( empty( $item->link ) || ! self::is_safe_remote_url( $item->link ) || ! get_post( absint( $item->post_id ) ) ) { continue; }
			$article = self::fetch_article_meta( $item->link );
			if ( empty( $article['full_content'] ) ) { continue; }
			wp_update_post( array(
				'ID'           => absint( $item->post_id ),
				'post_content' => $article['full_content'],
			) );
			$updated++;
		}
		return $updated;
	}

	private static function extract_article_content( $doc, $xp, $base_url ) {
		$settings = NPA_DB::settings();
		$custom_selectors = ! empty( $settings['extractor_selectors'] ) ? array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $settings['extractor_selectors'] ) ) ) : array();
		$selectors = array_merge( $custom_selectors, array(
			'article',
			'[role="main"] article',
			'.article__content',
			'.article-body',
			'.article-body__content',
			'.story-body',
			'.story-body__inner',
			'.entry-content',
			'.post-content',
			'.td-post-content',
			'.content__article-body',
			'.article-content',
			'.body-content',
			'.zn-body__paragraph',
		) );
		$best_html = '';
		$best_score = 0;
		foreach ( $selectors as $selector ) {
			$query = self::css_to_xpath( $selector );
			if ( empty( $query ) ) { continue; }
			$nodes = $xp->query( $query );
			if ( ! $nodes || ! $nodes->length ) { continue; }
			$html_parts = array();
			foreach ( $nodes as $node ) {
				$clean = self::clean_article_node( $node, $base_url );
				$text_len = strlen( trim( preg_replace( '/\s+/', ' ', $clean['text'] ) ) );
				if ( $text_len < 80 ) { continue; }
				$html_parts[] = $clean['html'];
			}
			$html = implode( "\n", $html_parts );
			$score = strlen( wp_strip_all_tags( $html ) );
			if ( $score > $best_score ) { $best_score = $score; $best_html = $html; }
		}
		if ( $best_score < 250 ) {
			$paras = $xp->query( '//p[string-length(normalize-space()) > 80]' );
			$parts = array();
			foreach ( $paras as $p ) {
				$text = trim( preg_replace( '/\s+/', ' ', $p->textContent ) );
				if ( self::is_bad_article_text( $text ) ) { continue; }
				$parts[] = '<p>' . esc_html( $text ) . '</p>';
				if ( count( $parts ) >= 40 ) { break; }
			}
			$best_html = implode( "\n", $parts );
		}
		return wp_kses_post( $best_html );
	}

	private static function css_to_xpath( $selector ) {
		$selector = trim( (string) $selector );
		if ( empty( $selector ) ) { return ''; }
		if ( 0 === strpos( $selector, '//' ) ) { return $selector; }
		$parts = preg_split( '/\s+/', $selector );
		$xpath = '';
		foreach ( $parts as $part ) {
			$tag = '*';
			$conditions = array();
			if ( preg_match( '/^[a-zA-Z0-9_-]+/', $part, $m ) ) { $tag = $m[0]; }
			if ( preg_match_all( '/\.([a-zA-Z0-9_-]+)/', $part, $m ) ) {
				foreach ( $m[1] as $class ) { $conditions[] = 'contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")'; }
			}
			if ( preg_match( '/#([a-zA-Z0-9_-]+)/', $part, $m ) ) { $conditions[] = '@id="' . $m[1] . '"'; }
			if ( preg_match( '/\[([^=\]]+)="?([^"\]]+)"?\]/', $part, $m ) ) { $conditions[] = '@' . $m[1] . '="' . $m[2] . '"'; }
			$xpath .= '//' . $tag . ( $conditions ? '[' . implode( ' and ', $conditions ) . ']' : '' );
		}
		return $xpath;
	}

	private static function clean_article_node( $node, $base_url ) {
		$clone = $node->cloneNode( true );
		$doc = new DOMDocument();
		$imported = $doc->importNode( $clone, true );
		$doc->appendChild( $imported );
		$xp = new DOMXPath( $doc );
		foreach ( $xp->query( '//script|//style|//noscript|//iframe|//form|//button|//nav|//aside|//*[contains(@class,"ad") or contains(@class,"advert") or contains(@class,"newsletter") or contains(@class,"share") or contains(@class,"social") or contains(@class,"related") or contains(@class,"promo") or contains(@class,"caption") or contains(@class,"video")]' ) as $bad ) {
			if ( $bad->parentNode ) { $bad->parentNode->removeChild( $bad ); }
		}
		foreach ( $xp->query( '//@src|//@href' ) as $attr ) {
			$attr->nodeValue = self::absolute_url( $attr->nodeValue, $base_url );
		}
		$allowed = array(
			'p' => array(), 'br' => array(), 'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(),
			'ul' => array(), 'ol' => array(), 'li' => array(), 'blockquote' => array(), 'h2' => array(), 'h3' => array(), 'h4' => array(),
			'a' => array( 'href' => array(), 'title' => array(), 'target' => array(), 'rel' => array() ),
			'img' => array( 'src' => array(), 'alt' => array(), 'width' => array(), 'height' => array(), 'loading' => array() ),
			'figure' => array(), 'figcaption' => array(),
		);
		$html = '';
		foreach ( $doc->childNodes as $child ) { $html .= $doc->saveHTML( $child ); }
		$html = wp_kses( $html, $allowed );
		$text = wp_strip_all_tags( $html );
		return array( 'html' => $html, 'text' => $text );
	}

	private static function is_bad_article_text( $text ) {
		$text = strtolower( trim( (string) $text ) );
		$bad = array( 'sign up', 'subscribe', 'advertisement', 'cookies', 'all rights reserved', 'follow us', 'read more', 'watch:', 'video:', 'newsletter' );
		foreach ( $bad as $needle ) { if ( false !== strpos( $text, $needle ) ) { return true; } }
		return false;
	}

	private static function meta_content( $xp, $attr, $value ) {
		$q = sprintf( '//meta[translate(@%s,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="%s"]/@content', $attr, strtolower( $value ) );
		$n = $xp->query( $q )->item( 0 );
		return $n ? trim( $n->nodeValue ) : '';
	}

	private static function choose_image( $item, $article ) {
		$settings = NPA_DB::settings();
		foreach ( array( $item['image_url'] ?? '', $article['og_image'] ?? '', $settings['default_fallback_image'] ?? '' ) as $url ) {
			$url = esc_url_raw( $url );
			if ( $url && self::is_safe_remote_url( $url ) ) { return $url; }
		}
		return '';
	}

	private static function clean_content( $html ) {
		$html = (string) $html;
		if ( empty( $html ) ) { return ''; }
		$allowed = array(
			'p' => array(), 'br' => array(), 'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(),
			'ul' => array(), 'ol' => array(), 'li' => array(), 'blockquote' => array(),
			'a' => array( 'href' => array(), 'title' => array(), 'target' => array(), 'rel' => array() ),
		);
		$content = wp_kses( $html, $allowed );
		$content = trim( preg_replace( '/\s+/', ' ', $content ) );
		return $content;
	}

	private static function clean_excerpt( $text ) {
		$text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );
		return sanitize_text_field( wp_trim_words( $text, 45, '...' ) );
	}

	private static function html_doc( $html ) {
		libxml_use_internal_errors( true );
		$dom = new DOMDocument();
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
		libxml_clear_errors();
		return $dom;
	}

	private static function absolute_url( $href, $base ) {
		$href = trim( (string) $href );
		if ( empty( $href ) || 0 === strpos( $href, '#' ) || preg_match( '/^(mailto|javascript|tel):/i', $href ) ) { return ''; }
		if ( preg_match( '#^https?://#i', $href ) ) { return $href; }
		$parts = wp_parse_url( $base );
		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) { return ''; }
		if ( 0 === strpos( $href, '//' ) ) { return $parts['scheme'] . ':' . $href; }
		$root = $parts['scheme'] . '://' . $parts['host'];
		if ( 0 === strpos( $href, '/' ) ) { return $root . $href; }
		$path = isset( $parts['path'] ) ? preg_replace( '#/[^/]*$#', '/', $parts['path'] ) : '/';
		return $root . $path . $href;
	}

	private static function looks_like_article( $link, $base ) {
		$l = wp_parse_url( $link ); $b = wp_parse_url( $base );
		if ( empty( $l['host'] ) || empty( $b['host'] ) || $l['host'] !== $b['host'] ) { return false; }
		$path = isset( $l['path'] ) ? $l['path'] : '';
		if ( preg_match( '#/(tag|author|category|video|live-tv|newsletter|login|account|privacy|terms)/?$#i', $path ) ) { return false; }
		return ( substr_count( trim( $path, '/' ), '/' ) >= 1 || preg_match( '/\d{4}/', $path ) );
	}

	private static function url_hash( $url ) { return md5( strtolower( untrailingslashit( strtok( esc_url_raw( $url ), '?' ) ) ) ); }

	private static function is_safe_remote_url( $url ) {
		$url = esc_url_raw( $url );
		$parts = wp_parse_url( $url );
		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) { return false; }
		$host = strtolower( $parts['host'] );
		if ( in_array( $host, array( 'localhost', '127.0.0.1', '0.0.0.0' ), true ) || preg_match( '/(^|\.)local$/', $host ) ) { return false; }
		$ip = gethostbyname( $host );
		if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, $flags ) ) { return false; }
		}
		return true;
	}

	private static function update_source_status( $id, $status, $message ) {
		global $wpdb;
		$wpdb->update( NPA_DB::table( 'sources' ), array( 'last_run' => current_time( 'mysql' ), 'last_status' => sanitize_key( $status ), 'last_message' => wp_kses_post( $message ), 'updated_at' => current_time( 'mysql' ) ), array( 'id' => absint( $id ) ), array( '%s','%s','%s','%s' ), array( '%d' ) );
	}

	private static function cleanup( $source_id ) {
		global $wpdb;
		$s = NPA_DB::settings();
		if ( absint( $s['auto_delete_days'] ) > 0 ) {
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . NPA_DB::table( 'items' ) . ' WHERE created_at < DATE_SUB(%s, INTERVAL %d DAY)', current_time( 'mysql' ), absint( $s['auto_delete_days'] ) ) );
		}
		if ( absint( $s['max_stored_per_source'] ) > 0 ) {
			$limit = absint( $s['max_stored_per_source'] );
			$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . NPA_DB::table( 'items' ) . ' WHERE source_id = %d ORDER BY published_at DESC, id DESC LIMIT 999999 OFFSET %d', absint( $source_id ), $limit ) );
			if ( $ids ) { $wpdb->query( 'DELETE FROM ' . NPA_DB::table( 'items' ) . ' WHERE id IN (' . implode( ',', array_map( 'absint', $ids ) ) . ')' ); }
		}
	}
}
