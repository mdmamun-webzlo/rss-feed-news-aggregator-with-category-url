<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_Elementor {
	public static function init() {
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
		add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register_widgets_legacy' ) );
	}

	public static function register_widgets( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) { return; }
		require_once NPA_DIR . 'includes/class-npa-elementor-widget.php';
		if ( class_exists( 'NPA_Elementor_News_Grid_Widget' ) ) {
			$widgets_manager->register( new NPA_Elementor_News_Grid_Widget() );
		}
	}

	public static function register_widgets_legacy() {
		if ( ! class_exists( '\Elementor\Plugin' ) || ! class_exists( '\Elementor\Widget_Base' ) ) { return; }
		require_once NPA_DIR . 'includes/class-npa-elementor-widget.php';
		if ( class_exists( 'NPA_Elementor_News_Grid_Widget' ) ) {
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new NPA_Elementor_News_Grid_Widget() );
		}
	}
}
