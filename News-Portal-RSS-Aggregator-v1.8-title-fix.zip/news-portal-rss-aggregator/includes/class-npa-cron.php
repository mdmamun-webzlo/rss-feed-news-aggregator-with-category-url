<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_Cron {
	const HOOK = 'npa_cron_runner';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );

		// Self-heal: if the plugin is active but the runner is missing, schedule it again.
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			self::schedule_runner();
		}
	}

	public static function schedules( $schedules ) {
		$schedules['npa_every_15_minutes'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'NPA Every 15 Minutes' );
		return $schedules;
	}

	public static function schedule_runner() {
		// Make sure our custom schedule exists during activation/manual repair.
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );

		if ( ! wp_next_scheduled( self::HOOK ) ) {
			$scheduled = wp_schedule_event( time() + 60, 'npa_every_15_minutes', self::HOOK );
			if ( false === $scheduled && ! wp_next_scheduled( self::HOOK ) ) {
				// Fallback to WordPress built-in hourly schedule if the custom interval is blocked.
				wp_schedule_event( time() + 60, 'hourly', self::HOOK );
			}
		}
	}

	public static function clear_runner() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function run() {
		global $wpdb;
		$sources = $wpdb->get_results( "SELECT * FROM " . NPA_DB::table( 'sources' ) . " WHERE status = 'active' ORDER BY id ASC" );
		foreach ( $sources as $source ) {
			if ( self::is_due( $source ) ) {
				NPA_Fetcher::fetch_source( $source->id );
				self::set_next_run( $source->id, $source->frequency );
			}
		}
	}

	public static function is_due( $source ) {
		if ( empty( $source->next_run ) || '0000-00-00 00:00:00' === $source->next_run ) {
			return true;
		}
		return strtotime( $source->next_run ) <= current_time( 'timestamp' );
	}

	public static function interval_seconds( $frequency ) {
		switch ( $frequency ) {
			case 'hourly': return HOUR_IN_SECONDS;
			case 'twicedaily': return 12 * HOUR_IN_SECONDS;
			case 'daily':
			default: return DAY_IN_SECONDS;
		}
	}

	public static function set_next_run( $source_id, $frequency ) {
		global $wpdb;
		$next = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) + self::interval_seconds( $frequency ) );
		$wpdb->update( NPA_DB::table( 'sources' ), array( 'next_run' => $next, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => absint( $source_id ) ), array( '%s','%s' ), array( '%d' ) );
	}
}
