<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_DB {
	public static function table( $name ) {
		global $wpdb;
		$allowed = array( 'sources', 'items', 'logs' );
		return in_array( $name, $allowed, true ) ? $wpdb->prefix . 'npa_' . $name : '';
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$sources = self::table( 'sources' );
		$items   = self::table( 'items' );
		$logs    = self::table( 'logs' );

		$sql1 = "CREATE TABLE $sources (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			source_name varchar(191) NOT NULL,
			source_url varchar(255) NOT NULL DEFAULT '',
			rss_url varchar(255) NOT NULL DEFAULT '',
			category_name varchar(191) NOT NULL DEFAULT '',
			source_type varchar(30) NOT NULL DEFAULT 'rss',
			frequency varchar(30) NOT NULL DEFAULT 'hourly',
			max_items int(11) NOT NULL DEFAULT 10,
			status varchar(20) NOT NULL DEFAULT 'active',
			last_run datetime NULL DEFAULT NULL,
			next_run datetime NULL DEFAULT NULL,
			last_status varchar(50) NOT NULL DEFAULT '',
			last_message text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY frequency (frequency),
			KEY next_run (next_run)
		) $charset;";

		$sql2 = "CREATE TABLE $items (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_name varchar(191) NOT NULL DEFAULT '',
			category_name varchar(191) NOT NULL DEFAULT '',
			title text NOT NULL,
			link varchar(500) NOT NULL,
			description text NULL,
			image_url varchar(500) NOT NULL DEFAULT '',
			guid varchar(500) NOT NULL DEFAULT '',
			url_hash char(32) NOT NULL,
			published_at datetime NULL DEFAULT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash),
			KEY post_id (post_id),
			KEY source_id (source_id),
			KEY published_at (published_at),
			KEY created_at (created_at)
		) $charset;";

		$sql3 = "CREATE TABLE $logs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			source_id bigint(20) unsigned NOT NULL DEFAULT 0,
			level varchar(20) NOT NULL DEFAULT 'info',
			message text NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY source_id (source_id),
			KEY level (level),
			KEY created_at (created_at)
		) $charset;";

		dbDelta( $sql1 );
		dbDelta( $sql2 );
		dbDelta( $sql3 );
		update_option( 'npa_db_version', NPA_VERSION );
	}

	public static function maybe_default_options() {
		$defaults = self::default_settings();
		if ( ! get_option( 'npa_settings' ) ) { add_option( 'npa_settings', $defaults ); }
		else { update_option( 'npa_settings', wp_parse_args( get_option( 'npa_settings', array() ), $defaults ) ); }
	}

	public static function default_settings() {
		return array(
			'default_items_per_source' => 10,
			'cache_duration'           => 30,
			'open_new_tab'             => 1,
			'nofollow_links'           => 1,
			'default_fallback_image'   => '',
			'show_source'              => 1,
			'show_date'                => 1,
			'show_excerpt'             => 1,
			'auto_delete_days'         => 0,
			'max_stored_per_source'    => 0,
			'create_wp_posts'          => 1,
			'auto_publish'             => 1,
			'post_status'              => 'publish',
			'download_featured_image'  => 1,
			'content_mode'             => 'summary',
			'extractor_selectors'      => '',
		);
	}

	public static function settings() { return wp_parse_args( get_option( 'npa_settings', array() ), self::default_settings() ); }

	public static function log( $source_id, $level, $message ) {
		global $wpdb;
		$wpdb->insert( self::table( 'logs' ), array(
			'source_id'  => absint( $source_id ),
			'level'      => sanitize_key( $level ),
			'message'    => wp_kses_post( $message ),
			'created_at' => current_time( 'mysql' ),
		), array( '%d', '%s', '%s', '%s' ) );
	}
}
