<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! class_exists( '\Elementor\Widget_Base' ) || class_exists( 'NPA_Elementor_News_Grid_Widget' ) ) { return; }

class NPA_Elementor_News_Grid_Widget extends \Elementor\Widget_Base {
	public function get_name() { return 'npa_news_grid'; }
	public function get_title() { return esc_html__( 'News Portal Grid', 'news-portal-rss-aggregator' ); }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_categories() { return array( 'general' ); }
	public function get_keywords() { return array( 'news', 'rss', 'aggregator', 'portal', 'posts' ); }
	public function get_style_depends() { return array( 'npa-frontend' ); }

	private function get_source_options() {
		global $wpdb;
		$options = array( '' => esc_html__( 'All Sources', 'news-portal-rss-aggregator' ) );
		$table = NPA_DB::table( 'sources' );
		$sources = $wpdb->get_results( "SELECT source_name FROM {$table} ORDER BY source_name ASC" );
		if ( $sources ) {
			foreach ( $sources as $source ) {
				$options[ $source->source_name ] = $source->source_name;
			}
		}
		return $options;
	}

	private function get_category_options() {
		$options = array( '' => esc_html__( 'All Categories', 'news-portal-rss-aggregator' ) );
		$terms = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) && $terms ) {
			foreach ( $terms as $term ) {
				$options[ $term->slug ] = $term->name;
			}
		}
		return $options;
	}

	protected function register_controls() {
		$this->start_controls_section( 'content_section', array( 'label' => esc_html__( 'News Query', 'news-portal-rss-aggregator' ) ) );
		$this->add_control( 'source', array(
			'label' => esc_html__( 'Source', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => $this->get_source_options(),
			'default' => '',
			'label_block' => true,
		) );
		$this->add_control( 'category', array(
			'label' => esc_html__( 'Category', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => $this->get_category_options(),
			'default' => '',
			'label_block' => true,
			'description' => esc_html__( 'Show posts from one WordPress category, or keep All Categories.', 'news-portal-rss-aggregator' ),
		) );
		$this->add_control( 'limit', array(
			'label' => esc_html__( 'Number of Posts', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::NUMBER,
			'min' => 1,
			'max' => 60,
			'step' => 1,
			'default' => 12,
		) );
		$this->add_control( 'columns', array(
			'label' => esc_html__( 'Columns', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => '3',
			'options' => array( '1' => '1', '2' => '2', '3' => '3', '4' => '4' ),
		) );
		$this->add_control( 'orderby', array(
			'label' => esc_html__( 'Order By', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'date',
			'options' => array( 'date' => esc_html__( 'Newest', 'news-portal-rss-aggregator' ), 'views' => esc_html__( 'Most Read', 'news-portal-rss-aggregator' ) ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'display_section', array( 'label' => esc_html__( 'Card Display', 'news-portal-rss-aggregator' ) ) );
		foreach ( array(
			'show_image' => esc_html__( 'Show Image', 'news-portal-rss-aggregator' ),
			'show_meta' => esc_html__( 'Show Source/Date', 'news-portal-rss-aggregator' ),
			'show_excerpt' => esc_html__( 'Show Excerpt', 'news-portal-rss-aggregator' ),
			'show_button' => esc_html__( 'Show Read Button', 'news-portal-rss-aggregator' ),
		) as $key => $label ) {
			$this->add_control( $key, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'news-portal-rss-aggregator' ), 'label_off' => esc_html__( 'No', 'news-portal-rss-aggregator' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'style_grid_section', array( 'label' => esc_html__( 'Grid Style', 'news-portal-rss-aggregator' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'grid_gap', array(
			'label' => esc_html__( 'Grid Gap', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
			'default' => array( 'size' => 24, 'unit' => 'px' ),
			'selectors' => array( '{{WRAPPER}} .npa-news-portal' => 'gap: {{SIZE}}{{UNIT}};' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_card_section', array( 'label' => esc_html__( 'Card Style', 'news-portal-rss-aggregator' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'card_bg', array(
			'label' => esc_html__( 'Card Background', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .npa-card' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name' => 'card_border',
			'selector' => '{{WRAPPER}} .npa-card',
		) );
		$this->add_responsive_control( 'card_radius', array(
			'label' => esc_html__( 'Border Radius', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'default' => array( 'size' => 18, 'unit' => 'px' ),
			'selectors' => array( '{{WRAPPER}} .npa-card' => 'border-radius: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name' => 'card_shadow',
			'selector' => '{{WRAPPER}} .npa-card',
		) );
		$this->add_responsive_control( 'card_padding', array(
			'label' => esc_html__( 'Content Padding', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors' => array( '{{WRAPPER}} .npa-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_image_section', array( 'label' => esc_html__( 'Image Style', 'news-portal-rss-aggregator' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'image_height', array(
			'label' => esc_html__( 'Image Height', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range' => array( 'px' => array( 'min' => 80, 'max' => 500 ) ),
			'selectors' => array( '{{WRAPPER}} .npa-image' => 'height: {{SIZE}}{{UNIT}}; aspect-ratio: auto;' ),
		) );
		$this->add_responsive_control( 'image_radius', array(
			'label' => esc_html__( 'Image Radius', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'selectors' => array( '{{WRAPPER}} .npa-image img, {{WRAPPER}} .npa-image' => 'border-radius: {{SIZE}}{{UNIT}};' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_text_section', array( 'label' => esc_html__( 'Text Style', 'news-portal-rss-aggregator' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'title_color', array( 'label' => esc_html__( 'Title Color', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-card h3 a' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'title_typography', 'selector' => '{{WRAPPER}} .npa-card h3, {{WRAPPER}} .npa-card h3 a' ) );
		$this->add_control( 'meta_color', array( 'label' => esc_html__( 'Meta Text Color', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-meta, {{WRAPPER}} .npa-meta span, {{WRAPPER}} .npa-meta time' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'meta_bg', array( 'label' => esc_html__( 'Meta Background', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-meta span, {{WRAPPER}} .npa-meta time' => 'background-color: {{VALUE}};' ) ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'meta_typography', 'selector' => '{{WRAPPER}} .npa-meta, {{WRAPPER}} .npa-meta span, {{WRAPPER}} .npa-meta time' ) );
		$this->add_control( 'excerpt_color', array( 'label' => esc_html__( 'Excerpt Color', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-card p' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'excerpt_typography', 'selector' => '{{WRAPPER}} .npa-card p' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_button_section', array( 'label' => esc_html__( 'Button Style', 'news-portal-rss-aggregator' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'button_color', array( 'label' => esc_html__( 'Button Text Color', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-read-more' => 'color: {{VALUE}} !important;' ) ) );
		$this->add_control( 'button_bg', array( 'label' => esc_html__( 'Button Background', 'news-portal-rss-aggregator' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .npa-read-more' => 'background-color: {{VALUE}};' ) ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'button_typography', 'selector' => '{{WRAPPER}} .npa-read-more' ) );
		$this->add_responsive_control( 'button_padding', array(
			'label' => esc_html__( 'Button Padding', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors' => array( '{{WRAPPER}} .npa-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'button_radius', array(
			'label' => esc_html__( 'Button Radius', 'news-portal-rss-aggregator' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
			'selectors' => array( '{{WRAPPER}} .npa-read-more' => 'border-radius: {{SIZE}}{{UNIT}};' ),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		wp_enqueue_style( 'npa-frontend' );
		$settings = $this->get_settings_for_display();
		$limit   = max( 1, min( 60, absint( $settings['limit'] ?? 12 ) ) );
		$columns = max( 1, min( 4, absint( $settings['columns'] ?? 3 ) ) );

		$args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $limit,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'meta_query'          => array( array( 'key' => '_npa_original_hash', 'compare' => 'EXISTS' ) ),
		);

		if ( ! empty( $settings['source'] ) ) {
			$args['meta_query'][] = array( 'key' => '_npa_source_name', 'value' => sanitize_text_field( $settings['source'] ), 'compare' => '=' );
		}
		if ( ! empty( $settings['category'] ) ) {
			$term = get_term_by( 'slug', sanitize_title( $settings['category'] ), 'category' );
			if ( $term && ! is_wp_error( $term ) ) { $args['cat'] = absint( $term->term_id ); }
		}
		if ( 'views' === ( $settings['orderby'] ?? 'date' ) ) {
			$args['meta_key'] = '_npa_read_count';
			$args['orderby'] = 'meta_value_num';
			$args['order'] = 'DESC';
		} else {
			$args['orderby'] = 'date';
			$args['order'] = 'DESC';
		}

		$query = new WP_Query( $args );
		if ( ! $query->have_posts() ) { echo '<div class="npa-empty">' . esc_html__( 'No news posts found.', 'news-portal-rss-aggregator' ) . '</div>'; return; }
		echo '<div class="npa-news-portal npa-elementor-grid npa-columns-' . esc_attr( $columns ) . '">';
		while ( $query->have_posts() ) {
			$query->the_post();
			$source = get_post_meta( get_the_ID(), '_npa_source_name', true );
			echo '<article class="npa-card">';
			if ( 'yes' === ( $settings['show_image'] ?? 'yes' ) && has_post_thumbnail() ) {
				echo '<a class="npa-image" href="' . esc_url( get_permalink() ) . '">' . get_the_post_thumbnail( get_the_ID(), 'medium_large', array( 'loading' => 'lazy' ) ) . '</a>';
			}
			echo '<div class="npa-content">';
			if ( 'yes' === ( $settings['show_meta'] ?? 'yes' ) ) {
				echo '<div class="npa-meta">';
				if ( $source ) { echo '<span>' . esc_html( $source ) . '</span>'; }
				$cats = get_the_category();
				if ( ! empty( $cats[0] ) ) { echo '<span>' . esc_html( $cats[0]->name ) . '</span>'; }
				echo '<time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date() ) . '</time>';
				echo '</div>';
			}
			echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
			if ( 'yes' === ( $settings['show_excerpt'] ?? 'yes' ) ) { echo '<p>' . esc_html( wp_trim_words( get_the_excerpt(), 24 ) ) . '</p>'; }
			if ( 'yes' === ( $settings['show_button'] ?? 'yes' ) ) { echo '<a class="npa-read-more" href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read Story', 'news-portal-rss-aggregator' ) . '</a>'; }
			echo '</div></article>';
		}
		echo '</div>';
		wp_reset_postdata();
	}
}
