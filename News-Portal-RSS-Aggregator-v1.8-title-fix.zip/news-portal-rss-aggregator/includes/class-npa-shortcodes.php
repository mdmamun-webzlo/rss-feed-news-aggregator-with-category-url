<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NPA_Shortcodes {
	public static function init() {
		add_shortcode( 'news_portal', array( __CLASS__, 'render' ) );
		add_shortcode( 'news_portal_sidebar', array( __CLASS__, 'render_sidebar' ) );
		add_action( 'template_redirect', array( __CLASS__, 'track_post_view' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function assets() {
		wp_register_style( 'npa-frontend', NPA_URL . 'public/assets/css/frontend.css', array(), NPA_VERSION );
	}

	public static function render( $atts ) {
		global $wpdb;
		wp_enqueue_style( 'npa-frontend' );
		$settings = NPA_DB::settings();
		$atts = shortcode_atts( array( 'source' => '', 'category' => '', 'limit' => absint( $settings['default_items_per_source'] ), 'layout' => 'grid', 'columns' => 3 ), $atts, 'news_portal' );
		$limit = max( 1, min( 60, absint( $atts['limit'] ) ) );
		$columns = max( 1, min( 4, absint( $atts['columns'] ) ) );

		$where = array( '1=1' ); $params = array();
		if ( '' !== $atts['source'] ) { $where[] = 'source_name = %s'; $params[] = sanitize_text_field( $atts['source'] ); }
		if ( '' !== $atts['category'] ) { $where[] = 'category_name = %s'; $params[] = sanitize_text_field( $atts['category'] ); }
		$sql = 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY published_at DESC, id DESC LIMIT %d';
		$params[] = $limit;
		$items = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		if ( ! $items ) { return '<div class="npa-empty">' . esc_html__( 'No news items found.', 'news-portal-rss-aggregator' ) . '</div>'; }

		$target = ! empty( $settings['open_new_tab'] ) ? ' target="_blank"' : '';
		$rel_parts = array( 'noopener' );
		if ( ! empty( $settings['nofollow_links'] ) ) { $rel_parts[] = 'nofollow'; }
		$rel = ' rel="' . esc_attr( implode( ' ', $rel_parts ) ) . '"';
		$fallback = esc_url( $settings['default_fallback_image'] );

		ob_start();
		?>
		<div class="npa-news-portal npa-layout-<?php echo esc_attr( $atts['layout'] ); ?> npa-columns-<?php echo esc_attr( $columns ); ?>">
			<?php foreach ( $items as $item ) : $img = $item->image_url ? esc_url( $item->image_url ) : $fallback; $card_url = ! empty( $item->post_id ) ? get_permalink( absint( $item->post_id ) ) : $item->link; $card_target = ! empty( $item->post_id ) ? '' : $target; $card_rel = ! empty( $item->post_id ) ? '' : $rel; ?>
				<article class="npa-card">
					<?php if ( $img ) : ?><a class="npa-image" href="<?php echo esc_url( $card_url ); ?>"<?php echo $card_target . $card_rel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $item->title ); ?>" loading="lazy"></a><?php endif; ?>
					<div class="npa-content">
						<div class="npa-meta">
							<?php if ( ! empty( $settings['show_source'] ) ) : ?><span><?php echo esc_html( $item->source_name ); ?></span><?php endif; ?>
							<?php if ( $item->category_name ) : ?><span><?php echo esc_html( $item->category_name ); ?></span><?php endif; ?>
							<?php if ( ! empty( $settings['show_date'] ) && $item->published_at ) : ?><time datetime="<?php echo esc_attr( $item->published_at ); ?>"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $item->published_at ) ) ); ?></time><?php endif; ?>
						</div>
						<h3><a href="<?php echo esc_url( $card_url ); ?>"<?php echo $card_target . $card_rel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_html( $item->title ); ?></a></h3>
						<?php if ( ! empty( $settings['show_excerpt'] ) && $item->description ) : ?><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $item->description ), 24 ) ); ?></p><?php endif; ?>
						<a class="npa-read-more" href="<?php echo esc_url( $card_url ); ?>"<?php echo $card_target . $card_rel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo ! empty( $item->post_id ) ? esc_html__( 'Read Summary', 'news-portal-rss-aggregator' ) : esc_html__( 'Read More', 'news-portal-rss-aggregator' ); ?></a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function render_sidebar( $atts ) {
		global $wpdb;
		wp_enqueue_style( 'npa-frontend' );
		$atts = shortcode_atts( array( 'source' => '', 'category' => '', 'limit' => 10 ), $atts, 'news_portal_sidebar' );
		$limit = max( 1, min( 30, absint( $atts['limit'] ) ) );
		$where = array( '1=1' ); $params = array();
		if ( '' !== $atts['source'] ) { $where[] = 'source_name = %s'; $params[] = sanitize_text_field( $atts['source'] ); }
		if ( '' !== $atts['category'] ) { $where[] = 'category_name = %s'; $params[] = sanitize_text_field( $atts['category'] ); }
		$sql = 'SELECT * FROM ' . NPA_DB::table( 'items' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY published_at DESC, id DESC LIMIT %d';
		$params[] = $limit;
		$items = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		if ( ! $items ) { return ''; }
		$fallback = esc_url( NPA_DB::settings()['default_fallback_image'] );
		ob_start(); ?>
		<div class="npa-sidebar-list">
			<?php foreach ( $items as $item ) : $img = $item->image_url ? esc_url( $item->image_url ) : $fallback; $url = ! empty( $item->post_id ) ? get_permalink( absint( $item->post_id ) ) : $item->link; ?>
				<a class="npa-sidebar-item" href="<?php echo esc_url( $url ); ?>">
					<?php if ( $img ) : ?><span class="npa-sidebar-img"><img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $item->title ); ?>" loading="lazy"></span><?php endif; ?>
					<span class="npa-sidebar-title"><?php echo esc_html( wp_trim_words( $item->title, 12 ) ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
		<?php return ob_get_clean();
	}

	public static function track_post_view() {
		if ( ! is_singular( 'post' ) ) { return; }
		$post_id = get_queried_object_id();
		if ( ! $post_id || ! get_post_meta( $post_id, '_npa_original_hash', true ) ) { return; }
		$cookie = 'npa_viewed_' . absint( $post_id );
		if ( ! empty( $_COOKIE[ $cookie ] ) ) { return; }
		$count = absint( get_post_meta( $post_id, '_npa_read_count', true ) );
		update_post_meta( $post_id, '_npa_read_count', $count + 1 );
		setcookie( $cookie, '1', time() + 12 * HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
	}

}
